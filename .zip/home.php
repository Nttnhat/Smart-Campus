<?php
require_once __DIR__ . '/config/auth.php';
$isAdminSession = (bool) current_admin_id();
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php echo csrf_meta(); ?>
    <title>TDTU | Trang chủ</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css?v=<?php echo @filemtime(__DIR__.'/css/style.css') ?: time(); ?>">
    <link rel="stylesheet" href="css/index.css">
</head>
<body>

    <header class="app-header">
        <a href="home.php" class="logo">
            <img src="image/logo.svg" alt="TDTU Logo" height="24" style="margin-right: 8px;">
            <span class="logo-text">BẢN ĐỒ KHUÔN VIÊN TDTU</span>
        </a>

        <nav class="nav-links">
            <a href="home.php" class="active">Trang chủ</a>
            <a href="campus-map.php">Bản đồ</a>
            <a href="navigation.php">Tìm đường</a>
        </nav>

        <?php include __DIR__ . '/includes/user-menu.php'; ?>
    </header>

    <main class="home-page">
        <section class="hero-section">
            <div class="hero-copy animate-fade-in">
                <span class="eyebrow">SMART CAMPUS · TÔN ĐỨC THẮNG UNIVERSITY</span>
                <h1>Khám phá khuôn viên <span>TDTU</span> dễ dàng hơn</h1>
                <p class="hero-description">
                    Trang chủ này tập trung giới thiệu nhanh về hệ thống bản đồ khuôn viên và dẫn bạn tới
                    bản đồ thực tế tại cơ sở chính của Trường Đại học Tôn Đức Thắng.
                </p>
                <div class="hero-badges">
                    <span class="hero-badge">Cơ sở chính: 19 Nguyễn Hữu Thọ</span>
                    <span class="hero-badge">Bản đồ thực tế bằng OpenStreetMap</span>
                </div>
                <div class="hero-actions">
                    <a href="campus-map.php" class="btn btn-secondary hero-btn">
                        <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="3 6 9 3 15 6 21 3 21 18 15 21 9 18 3 21"></polygon><line x1="9" y1="3" x2="9" y2="21"></line><line x1="15" y1="6" x2="15" y2="21"></line></svg>
                        Khám phá bản đồ
                    </a>
                    <a href="navigation.php" class="btn btn-outline hero-btn">
                        <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
                        Tìm kiếm vị trí
                    </a>
                </div>
            </div>

            <div class="campus-overview-card" aria-label="Thông tin nhanh khuôn viên">
                <div class="overview-top">
                    <span>Thông tin nhanh khuôn viên</span>
                    <span class="status-pill"><i></i> Sẵn sàng sử dụng</span>
                </div>
                <div class="campus-mini-map campus-info-panel">
                    <div class="info-panel-header">
                        <img src="image/logo.svg" alt="Logo TDTU">
                        <div>
                            <strong>Đại học Tôn Đức Thắng</strong>
                            <span>Cơ sở chính · TP. Hồ Chí Minh</span>
                        </div>
                    </div>
                    <div class="info-panel-list">
                        <div>
                            <strong>Địa chỉ</strong>
                            <span>19 Nguyễn Hữu Thọ, phường Tân Hưng, TP. Hồ Chí Minh</span>
                        </div>
                        <div>
                            <strong>Mục tiêu của web</strong>
                            <span>Tra cứu địa điểm, tìm đường trong trường, hỗ trợ sinh viên định vị khu vực nhanh hơn.</span>
                        </div>
                        <div>
                            <strong>Dữ liệu bản đồ</strong>
                            <span>Hiển thị trên nền bản đồ thực tế; phù hợp để tìm các khu vực ngoài trời trong khuôn viên.</span>
                        </div>
                    </div>
                    <a href="navigation.php" class="info-panel-link">Mở trang tìm vị trí thực tế →</a>
                </div>
                <div class="overview-footer">
                    <div><strong>Tra cứu</strong><span>Tòa học · thư viện</span></div>
                    <div><strong>Tìm nhanh</strong><span>Ăn uống · tiện ích</span></div>
                    <div><strong>Dẫn đường</strong><span>Lộ trình ngắn nhất</span></div>
                </div>
            </div>
        </section>

        <section class="stats-section section-wrap" aria-label="Thông tin tổng quan trường">
            <div class="stat-card">
                <div class="stat-icon">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 21h18"></path><path d="M5 21V7l8-4v18"></path><path d="M19 21V11l-6-3"></path></svg>
                </div>
                <div><strong>Cơ sở chính</strong><span>19 Nguyễn Hữu Thọ, phường Tân Hưng</span></div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="17" rx="2"></rect><path d="M7 8h2M7 12h2M7 16h2M15 8h2M15 12h2M15 16h2"></path></svg>
                </div>
                <div><strong>Tòa & khu chức năng</strong><span>Giảng đường, thư viện, thể thao, dịch vụ</span></div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 21s7-4.35 7-11a7 7 0 1 0-14 0c0 6.65 7 11 7 11z"></path><circle cx="12" cy="10" r="2"></circle></svg>
                </div>
                <div><strong>Bản đồ thực tế</strong><span>Tra cứu trên nền OpenStreetMap</span></div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 19.5V4.5A2.5 2.5 0 0 1 6.5 2H20v17H6.5A2.5 2.5 0 0 0 4 21.5"></path><path d="M8 6h8M8 10h8"></path></svg>
                </div>
                <div><strong>Hỗ trợ sinh viên</strong><span>Tìm đường và xác định vị trí ngoài trời</span></div>
            </div>
        </section>

        <section class="section-wrap introduction-section">
            <div class="section-heading">
                <div>
                    <span class="section-kicker">GIỚI THIỆU</span>
                    <h2>Giải pháp bản đồ khuôn viên trực quan và thực tế</h2>
                </div>
                <p>
                    Hệ thống được thiết kế để sinh viên dễ dàng tìm thấy giảng đường, thư viện,
                    khu tiện ích, thể thao và các điểm hỗ trợ cần thiết trong khuôn viên.
                </p>
            </div>
            <div class="feature-grid">
                <article class="feature-card">
                    <div class="feature-number">01</div>
                    <h3>Trang chủ ngắn gọn</h3>
                    <p>Giới thiệu nhanh về mục tiêu hệ thống, cơ sở chính và các nhóm chức năng quan trọng.</p>
                </article>
                <article class="feature-card">
                    <div class="feature-number">02</div>
                    <h3>Bản đồ thực tế</h3>
                    <p>Sử dụng nền bản đồ thật để người dùng dễ đối chiếu với khuôn viên bên ngoài thực tế.</p>
                </article>
                <article class="feature-card">
                    <div class="feature-number">03</div>
                    <h3>Tìm kiếm địa điểm</h3>
                    <p>Hỗ trợ tìm theo tên hoặc danh mục như tòa học, ăn uống, hầm xe, hỗ trợ sinh viên.</p>
                </article>
                <article class="feature-card">
                    <div class="feature-number">04</div>
                    <h3>Dẫn đường nội bộ</h3>
                    <p>Ưu tiên lộ trình ngắn nhất để sinh viên đi trong khuôn viên thuận tiện hơn.</p>
                </article>
            </div>
        </section>

        <section class="functions-section">
            <div class="section-wrap">
                <div class="section-heading inverse-heading">
                    <div>
                        <span class="section-kicker">CHỨC NĂNG HỆ THỐNG</span>
                        <h2>Tìm đúng nơi, đi đúng đường</h2>
                    </div>
                    <p>Mỗi chức năng được thiết kế để giảm thời gian tìm kiếm và giúp người dùng định hướng trực quan hơn trong khuôn viên.</p>
                </div>
                <div class="function-grid">
                    <a class="function-card" href="campus-map.php">
                        <span class="function-icon">
                            <svg width="27" height="27" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="3 6 9 3 15 6 21 3 21 18 15 21 9 18 3 21"></polygon><line x1="9" y1="3" x2="9" y2="21"></line><line x1="15" y1="6" x2="15" y2="21"></line></svg>
                        </span>
                        <h3>Bản đồ khuôn viên</h3>
                        <p>Hiển thị khuôn viên trên bản đồ nền thực tế, thuận tiện để đối chiếu khi di chuyển ngoài trời.</p>
                        <span class="function-link">Mở bản đồ →</span>
                    </a>
                    <a class="function-card" href="navigation.php">
                        <span class="function-icon">
                            <svg width="27" height="27" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
                        </span>
                        <h3>Tìm kiếm địa điểm</h3>
                        <p>Tìm theo tên hoặc danh mục và nhận gợi ý các địa điểm phù hợp trong khuôn viên.</p>
                        <span class="function-link">Tìm ngay →</span>
                    </a>
                    <a class="function-card" href="navigation.php?mode=mylocation">
                        <span class="function-icon">
                            <svg width="27" height="27" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"></circle><circle cx="12" cy="12" r="8"></circle><path d="M12 2v2M12 20v2M2 12h2M20 12h2"></path></svg>
                        </span>
                        <h3>Vị trí của tôi</h3>
                        <p>Xác định vị trí hiện tại ngoài trời và neo lên khu vực phù hợp trong khuôn viên.</p>
                        <span class="function-link">Xem vị trí →</span>
                    </a>
                    <a class="function-card" href="navigation.php">
                        <span class="function-icon">
                            <svg width="27" height="27" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 18h14"></path><path d="M6 15l3-8 4 5 2-3 3 6"></path></svg>
                        </span>
                        <h3>Dẫn đường trong trường</h3>
                        <p>Đề xuất lộ trình, ưu tiên đường ngắn nhất và trình bày từng bước di chuyển rõ ràng.</p>
                        <span class="function-link">Bắt đầu dẫn đường →</span>
                    </a>
                </div>
            </div>
        </section>

        <section class="section-wrap places-section">
            <div class="section-heading compact-heading">
                <div>
                    <span class="section-kicker">ĐỊA ĐIỂM NỔI BẬT</span>
                    <h2>Những nơi thường được tìm kiếm</h2>
                </div>
                <a class="text-link" href="navigation.php">Xem trên bản đồ thực tế →</a>
            </div>
            <div class="place-grid">
                <a class="place-card" href="navigation.php?slug=toa-g">
                    <div class="place-visual place-library"><span>📚</span></div>
                    <div class="place-content"><span class="place-category">HỌC TẬP</span><h3>Thư viện</h3><p>Không gian học tập, tra cứu và tự học.</p></div>
                </a>
                <a class="place-card" href="navigation.php?slug=can-tin">
                    <div class="place-visual place-food"><span>🍽️</span></div>
                    <div class="place-content"><span class="place-category">ĂN UỐNG</span><h3>Căn tin</h3><p>Khu ăn uống phục vụ sinh viên trong khuôn viên.</p></div>
                </a>
                <a class="place-card" href="navigation.php?slug=nha-thi-dau">
                    <div class="place-visual place-sport"><span>🏀</span></div>
                    <div class="place-content"><span class="place-category">THỂ THAO</span><h3>Nhà thi đấu</h3><p>Khu vực phục vụ luyện tập và hoạt động thể thao.</p></div>
                </a>
                <a class="place-card" href="navigation.php?slug=cong-1">
                    <div class="place-visual place-gate"><span>🚪</span></div>
                    <div class="place-content"><span class="place-category">DI CHUYỂN</span><h3>Cổng chính</h3><p>Mốc định hướng quen thuộc khi bắt đầu tìm đường.</p></div>
                </a>
            </div>
        </section>

        <section class="section-wrap cta-section">
            <div>
                <span class="section-kicker">BẮT ĐẦU</span>
                <h2>Bạn đang cần tìm một địa điểm?</h2>
                <p>Nhập điểm đến, chọn gợi ý phù hợp và xem lộ trình ngay trên bản đồ thực tế.</p>
            </div>
            <a href="navigation.php" class="btn btn-secondary hero-btn">Tìm vị trí ngay</a>
        </section>
    </main>

    <script src="js/main.js?v=<?php echo @filemtime(__DIR__.'/js/main.js') ?: time(); ?>"></script>
</body>
</html>
